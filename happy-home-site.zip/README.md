# 幸福小屋 · 可部署预订网站

基于视觉样板整理的 Vite + Supabase 网站源码。访客可用中文、法语、英语或马达加斯加语浏览并提交住宿申请；管理员登录后可处理申请、用 WhatsApp 联系客人、更新 8 间客房状态。管理页面通过 Supabase Realtime 接收新申请和房态更新。

## 本机运行

需要 Node.js 20 或更新版本。

1. 在 Supabase 新建项目。
2. 打开 Supabase SQL Editor，执行 supabase/schema.sql。
3. 在 Authentication → Users 中创建店主账号（邮箱/密码）。复制该用户 UUID，在 SQL Editor 将下列邮箱改成店主邮箱后执行：

   ~~~sql
   insert into public.admin_users (user_id)
   select id from auth.users where lower(email) = lower('owner@example.com')
   on conflict (user_id) do nothing;
   ~~~

4. 从项目 API 设置中复制 Project URL 和 anon/publishable key。复制 .env.example 为 .env.local，填入：

   ~~~env
   VITE_SUPABASE_URL=https://你的项目.supabase.co
   VITE_SUPABASE_ANON_KEY=你的公开anon或publishable key
   ~~~

5. 在此目录运行：

   ~~~sh
   npm install
   npm run dev
   ~~~

   Vite 会显示本地网址。生产构建用 npm run build，输出目录为 dist/。

## 部署到 Vercel

1. 将 happy-home-site 文件夹提交到 GitHub。
2. 在 Vercel 导入仓库；Framework 选择 Vite，Build Command 为 npm run build，Output Directory 为 dist。
3. 在项目 Settings → Environment Variables 添加 VITE_SUPABASE_URL 和 VITE_SUPABASE_ANON_KEY，并选择 Production（需要预览时也勾选 Preview）。重新部署以载入变量。
4. 在 Supabase Authentication → URL Configuration 中把 Site URL 设为正式网址；把本机和预览地址按需加入 Redirect URLs。
5. 在 Supabase Authentication 设置里关闭公开注册。管理员只能使用你创建并加入 public.admin_users 的账号。

附有 vercel.json，可用 Vercel CLI 部署。Netlify、Cloudflare Pages 等支持 Vite 的平台也可使用相同构建命令和 dist 输出目录。

## 安全与运行说明

- 浏览器只使用 Supabase 的公开 anon/publishable key；RLS 策略限制访客只能新增待确认申请，管理员名单中的用户才能查看和处理申请、改动房态。绝不要把 Supabase service_role key 放入 VITE_ 变量或前端文件。
- 预订先作为“待确认申请”写入数据库，店主确认后再联系客人；本版没有在线付款、自动分房或按日期自动锁房。
- 店主登录并打开管理页面时可收到实时更新；允许浏览器通知后，新申请可弹出系统通知。手机浏览器若关闭网页或暂停标签，系统推送仍需额外配置 Web Push（VAPID 密钥与服务端函数）。
- 数据存储在 Supabase，不依赖单台设备的浏览器缓存；客人与管理页面可用不同设备访问同一线上数据。
- 价目、位置和服务文案可在 index.html 与 src/translations.js 中按实际经营信息修改。
