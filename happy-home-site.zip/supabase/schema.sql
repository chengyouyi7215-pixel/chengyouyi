-- Run once in Supabase SQL Editor. Reservations are requests until staff confirms them.
create extension if not exists pgcrypto;
create table if not exists public.admin_users (
  user_id uuid primary key references auth.users(id) on delete cascade,
  created_at timestamptz not null default now()
);
alter table public.admin_users enable row level security;
drop policy if exists "admins can read own membership" on public.admin_users;
create policy "admins can read own membership" on public.admin_users for select to authenticated using (user_id = (select auth.uid()));
grant select on public.admin_users to authenticated;

create table if not exists public.reservations (
  id uuid primary key default gen_random_uuid(),
  name text not null check (char_length(name) between 1 and 120),
  phone text not null check (char_length(phone) between 5 and 40),
  arrival date not null,
  departure date not null check (departure > arrival),
  guests integer not null default 1 check (guests between 1 and 20),
  language text,
  note text check (note is null or char_length(note) <= 1500),
  status text not null default 'pending' check (status in ('pending','confirmed','declined','completed')),
  created_at timestamptz not null default now()
);
create index if not exists reservations_created_at_idx on public.reservations (created_at desc);
create index if not exists reservations_dates_idx on public.reservations (arrival, departure);
alter table public.reservations enable row level security;
drop policy if exists "anyone can request a reservation" on public.reservations;
create policy "anyone can request a reservation" on public.reservations for insert to anon, authenticated with check (status = 'pending');
drop policy if exists "admins can read reservations" on public.reservations;
create policy "admins can read reservations" on public.reservations for select to authenticated using (exists (select 1 from public.admin_users a where a.user_id = (select auth.uid())));
drop policy if exists "admins can update reservations" on public.reservations;
create policy "admins can update reservations" on public.reservations for update to authenticated using (exists (select 1 from public.admin_users a where a.user_id = (select auth.uid()))) with check (exists (select 1 from public.admin_users a where a.user_id = (select auth.uid())));
revoke all on public.reservations from anon, authenticated;
grant insert (name, phone, arrival, departure, guests, language, note) on public.reservations to anon, authenticated;
grant select, update on public.reservations to authenticated;

create table if not exists public.room_status (
  room_number integer primary key check (room_number between 1 and 8),
  status text not null default '空房' check (status in ('空房','已预订','已入住','清洁中')),
  updated_at timestamptz not null default now(),
  updated_by uuid references auth.users(id)
);
insert into public.room_status (room_number) select n from generate_series(1,8) n on conflict (room_number) do nothing;
alter table public.room_status enable row level security;
drop policy if exists "admins can manage room status" on public.room_status;
create policy "admins can manage room status" on public.room_status for all to authenticated using (exists (select 1 from public.admin_users a where a.user_id = (select auth.uid()))) with check (exists (select 1 from public.admin_users a where a.user_id = (select auth.uid())));
grant select, update on public.room_status to authenticated;

-- Realtime subscriptions are RLS-protected: only authorized admins can read rows.
do $$ begin
  if not exists (select 1 from pg_publication_tables where pubname='supabase_realtime' and schemaname='public' and tablename='reservations') then
    alter publication supabase_realtime add table public.reservations;
  end if;
  if not exists (select 1 from pg_publication_tables where pubname='supabase_realtime' and schemaname='public' and tablename='room_status') then
    alter publication supabase_realtime add table public.room_status;
  end if;
end $$;
