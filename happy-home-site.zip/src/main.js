import { createClient } from '@supabase/supabase-js';
import './style.css';
import './translations.js';

const cfg = import.meta.env;
const ready = Boolean(cfg.VITE_SUPABASE_URL && cfg.VITE_SUPABASE_ANON_KEY);
const db = ready ? createClient(cfg.VITE_SUPABASE_URL, cfg.VITE_SUPABASE_ANON_KEY) : null;
let user = null, channel = null, lastRequestAt = null;
const $ = (s) => document.querySelector(s);
const esc = (v) => String(v ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));

window.setLang = (lang, button) => {
  document.querySelectorAll('.langs button').forEach(x => x.classList.remove('on'));
  button.classList.add('on');
  document.querySelectorAll('[data-k]').forEach(el => {
    const value = window.TRANSLATIONS[lang]?.[el.dataset.k];
    if (value) el.innerHTML = value;
  });
  document.documentElement.lang = lang === 'zh' ? 'zh-CN' : lang;
};
window.closeAdmin = () => $('#admin').classList.remove('open');
window.closeSuccess = () => $('#success').classList.remove('open');
window.openAdmin = async () => {
  if (!ready) { alert('请先配置 Supabase：复制 .env.example 为 .env.local 并填写项目 URL 和 anon key。'); return; }
  const { data } = await db.auth.getSession();
  user = data.session?.user || null;
  if (!user) { $('#login').classList.add('open'); return; }
  $('#admin').classList.add('open');
  await loadDashboard();
  if ('Notification' in window && Notification.permission === 'default') Notification.requestPermission();
};
window.signOut = async () => { await db.auth.signOut(); user = null; closeAdmin(); };

function setError(message) { $('#loginError').textContent = message || ''; }
$('#loginForm').addEventListener('submit', async (event) => {
  event.preventDefault(); setError('');
  if (!ready) return setError('尚未配置数据库连接。');
  const values = Object.fromEntries(new FormData(event.currentTarget));
  const { data, error } = await db.auth.signInWithPassword({ email: values.email, password: values.password });
  if (error) return setError('登录失败，请检查账号和密码。');
  user = data.user; $('#login').classList.remove('open'); $('#admin').classList.add('open');
  await loadDashboard();
  if ('Notification' in window && Notification.permission === 'default') Notification.requestPermission();
});

document.querySelector('#bookingForm').addEventListener('submit', async (event) => {
  event.preventDefault();
  if (!ready) return alert('预订服务尚未配置，请稍后再试或直接联系民宿。');
  const f = Object.fromEntries(new FormData(event.currentTarget));
  if (f.departure <= f.arrival) return alert('退房日期须晚于入住日期。');
  const row = { name:f.name.trim(), phone:f.phone.trim(), arrival:f.arrival, departure:f.departure, guests:Number(f.guests), language:f.language, note:f.note.trim() || null };
  const { error } = await db.from('reservations').insert(row);
  if (error) { alert('暂时无法提交，请稍后重试或直接联系民宿。'); console.error(error); return; }
  $('#success').classList.add('open'); event.currentTarget.reset();
});

async function loadDashboard() {
  if (!db || !user) return;
  const [roomsResult, requestsResult] = await Promise.all([
    db.from('room_status').select('room_number,status').order('room_number'),
    db.from('reservations').select('id,name,phone,arrival,departure,guests,language,note,status,created_at').order('created_at',{ascending:false}).limit(50)
  ]);
  if (roomsResult.error || requestsResult.error) {
    $('#reservations').innerHTML = '<div class="empty">读取失败。请确认该账号已加入管理员名单。</div>';
    return;
  }
  const roomList = $('#roomList'); roomList.innerHTML = '';
  (roomsResult.data || []).forEach(room => {
    const tile = document.createElement('div'); tile.className = 'tile';
    tile.innerHTML = '<b>房间 '+String(room.room_number).padStart(2,'0')+'</b><select aria-label="房间状态">'+['空房','已预订','已入住','清洁中'].map(s=>'<option '+(s===room.status?'selected':'')+'>'+s+'</option>').join('')+'</select>';
    tile.querySelector('select').addEventListener('change', e => updateRoom(room.room_number,e.target.value)); roomList.append(tile);
  });
  const requests = requestsResult.data || [];
  $('#occupied').textContent = roomsResult.data.filter(r=>r.status==='已入住'||r.status==='已预订').length;
  $('#pending').textContent = requests.filter(r=>r.status==='pending').length;
  const box=$('#reservations');
  if (!requests.length) { box.innerHTML='<div class="empty">暂无预订申请。</div>'; return; }
  box.innerHTML='';
  requests.forEach(r=>{
    const card=document.createElement('article');card.className='reservation';
    const wa = 'https://wa.me/'+String(r.phone).replace(/\D/g,'');
    card.innerHTML='<div><b>'+esc(r.name)+' · '+esc(r.guests)+' 位</b><small>'+esc(r.arrival)+' → '+esc(r.departure)+' · '+esc(r.phone)+'<br>'+esc(r.language||'')+(r.note?' · '+esc(r.note):'')+'<br><a target="_blank" rel="noreferrer" href="'+wa+'">WhatsApp 联系 ↗</a></small></div><select aria-label="预订处理状态"><option value="pending">待确认</option><option value="confirmed">已确认</option><option value="declined">已婉拒</option><option value="completed">已完成</option></select>';
    const statusSelect=card.querySelector('select');statusSelect.value=r.status;statusSelect.addEventListener('change',e=>updateReservation(r.id,e.target.value));box.append(card);
  });
}
async function updateReservation(id,status) {
  const {error}=await db.from('reservations').update({status}).eq('id',id);
  if(error){alert('预订状态更新失败，请检查管理员权限。');await loadDashboard();}
}
async function updateRoom(number,status) {
  const { error } = await db.from('room_status').update({status,updated_at:new Date().toISOString(),updated_by:user.id}).eq('room_number',number);
  if(error){alert('房态更新失败，请检查管理员权限。');await loadDashboard();}
}
function subscribeAdmin() {
  if (!db || channel) return;
  channel = db.channel('happy-home-admin').on('postgres_changes',{event:'*',schema:'public',table:'reservations'},payload=>{
    loadDashboard();
    if(payload.eventType==='INSERT' && user && 'Notification' in window && Notification.permission==='granted') new Notification('幸福小屋：收到新预订申请',{body:(payload.new.name||'客人')+' · '+payload.new.arrival});
  }).on('postgres_changes',{event:'*',schema:'public',table:'room_status'},()=>loadDashboard()).subscribe();
}
if (ready) {
  db.auth.getSession().then(({data})=>{user=data.session?.user||null;});
  db.auth.onAuthStateChange((_event,session)=>{user=session?.user||null;if(user)subscribeAdmin();else if(channel){db.removeChannel(channel);channel=null;}});
}
document.querySelectorAll('input[type=date]').forEach(input=>input.min=new Date().toISOString().slice(0,10));
